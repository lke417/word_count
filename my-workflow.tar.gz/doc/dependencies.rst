

Dependencies
============

Required
--------

- Python
- Numpy
- Matplotlib
- Make or Snakemake


Optional
--------

- Docker
