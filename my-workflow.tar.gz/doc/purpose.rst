

Purpose
=======

Write me ...


Zipf's law
----------

Write me ...
